# Starshine glitter effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/kucsatax/pen/vyWevX](https://codepen.io/kucsatax/pen/vyWevX).

starshine, glitter, glittering, shine effect
with css jquery and base64 star img